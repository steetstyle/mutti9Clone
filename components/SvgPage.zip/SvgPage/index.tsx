import { View } from "react-native"
import { RightCorner } from "./Svgs/RIghtCorner"
import { styles } from "./styles";
import { BackgroundSvg } from "./Svgs/BackgroundSvg";


interface SvgPageProps {
	topSide?: React.ReactNode;
	topSideContainerStyle?: any;

	bottomSide?: React.ReactNode;
	bottomSideContainerStyle?: any;

	backgroundSvgStyle?: {
		top?: number;
		bottom?: number;
		right?: number;
		left?: number;
	}
}
export const SvgPage = ({ topSide, topSideContainerStyle, bottomSide, bottomSideContainerStyle, backgroundSvgStyle }: SvgPageProps) => {

	return (
		<View style={styles.container}>
			<BackgroundSvg style={[styles.backgroundSvgContainer, backgroundSvgStyle]} />
			{
				topSide &&
				<View style={[styles.topSideContainer, topSideContainerStyle ]}>
					{topSide}
				</View>
			}

			{
				bottomSide &&
				<View style={[styles.bottomSideContainer, bottomSideContainerStyle ]}>
					<RightCorner style={styles.rightCorner}/>
					{bottomSide}
				</View>
			}
		</View>
	)
}